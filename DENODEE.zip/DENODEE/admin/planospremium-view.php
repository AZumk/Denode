


<div class="row">
	<div class="col-md-12">
<div class="btn-group pull-right">

</div>


<div class="card">
  <div class="card-header" data-background-color="blue">
      <h4 class="title">Planos Premium</h4>
  </div>
  <div class="card-content table-responsive">
	<div class="main-content">
		

						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<div class="row">
									<div class="col-xs-6 col-sm-3 pricing-box">
										<div class="widget-box widget-color-dark">
											<div class="widget-header">
												<h5 class="widget-title bigger lighter">Plano Basic </h5>
											</div>

											<div class="widget-body">
												<div class="widget-main">
													<ul class="list-unstyled spaced2">
														<li>
															<i class="ace-icon fa fa-check green"></i>
															10 GB Disk Space
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															200 GB Bandwidth
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															100 Email Accounts
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															10 MySQL Databases
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															$10 Ad Credit
														</li>

														<li>
															<i class="ace-icon fa fa-times red"></i>
															Free Domain
														</li>
													</ul>

													<hr />
													<div class="price">
														$5
														<small>/mês</small>
													</div>
												</div>

												<div>
													<a href="#" class="btn btn-block " data-background-color="blue">
													
														<span>Comprar</span>
													</a>
												</div>
											</div>
										</div>
									</div>

									<div class="col-xs-6 col-sm-3 pricing-box">
										<div class="widget-box widget-color-orange">
											<div class="widget-header">
												<h5 class="widget-title bigger lighter">Plano Starter </h5>
											</div>

											<div class="widget-body">
												<div class="widget-main">
													<ul class="list-unstyled spaced2">
														<li>
															<i class="ace-icon fa fa-check green"></i>
															50 GB Disk Space
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															1 TB Bandwidth
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															1000 Email Accounts
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															100 MySQL Databases
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															$25 Ad Credit
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															Free Domain
														</li>
													</ul>

													<hr />
													<div class="price">
														$10
														<small>/mês</small>
													</div>
												</div>

												<div>
													<a href="#" class="btn btn-block btn-warning">
														
														<span>Comprar</span>
													</a>
												</div>
											</div>
										</div>
									</div>

									<div class="col-xs-6 col-sm-3 pricing-box">
										<div class="widget-box widget-color-blue">
											<div class="widget-header">
												<h5 class="widget-title bigger lighter">Plano Business </h5>
											</div>

											<div class="widget-body">
												<div class="widget-main">
													<ul class="list-unstyled spaced2">
														<li>
															<i class="ace-icon fa fa-check green"></i>
															200 GB Disk Space
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															Unlimited Bandwidth
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															1000 Email Accounts
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															200 MySQL Databases
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															$25 Ad Credit
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															Free Domain
														</li>
													</ul>

													<hr />
													<div class="price">
														$15
														<small>/mês</small>
													</div>
												</div>

												<div>
													<a href="#" class="btn btn-block btn-primary">
													
														<span>Comprar</span>
													</a>
												</div>
											</div>
										</div>
									</div>

									<div class="col-xs-6 col-sm-3 pricing-box">
										<div class="widget-box widget-color-green">
											<div class="widget-header">
												<h5 class="widget-title bigger lighter">Plano Ultimate </h5>
											</div>

											<div class="widget-body">
												<div class="widget-main">
													<ul class="list-unstyled spaced2">
														<li>
															<i class="ace-icon fa fa-check green"></i>
															Unlimited Space
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															Unlimited Bandwidth
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															Unlimited Email Accounts
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															Unlimited MySQL Databases
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															$50 Ad Credit
														</li>

														<li>
															<i class="ace-icon fa fa-check green"></i>
															2 Free Domains
														</li>
													</ul>

													<hr />
													<div class="price">
														$25
														<small>/mês</small>
													</div>
												</div>

												<div>
													<a href="#" class="btn btn-block btn-success"  data-background-color="blue">
													
														<span>Comprar</span>
													</a>
													<br><br><br><br>
												</div>
											</div>
										</div>
									</div>
								</div>

								
									</div>
								</div><!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

		</div><!-- /.main-container -->

			
			</div>
			</div>
	

	</div>
</div>