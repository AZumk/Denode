<div class="row">
	<div class="col-md-12">
<div class="btn-group pull-right">

</div>


<div class="card">
  <div class="card-header" data-background-color="blue">
      <h4 class="title">Feedback</h4>
  </div>
  <div class="card-content table-responsive">

  	
<a href="./index.php?view=novaatividade" class="btn btn-info">Novo Feedback</a>

			
			</div>
			</div>
	

	</div>
</div>