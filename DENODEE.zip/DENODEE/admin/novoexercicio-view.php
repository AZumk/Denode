<div class="row">
	<div class="col-md-12">
<div class="card">
  <div class="card-header" data-background-color="blue">
      <h4 class="title">Novo Exercício</h4>
  </div>
  <div class="card-content table-responsive">

		<form class="form-horizontal" method="post" id="addproduct" action="index.php?view=addexercicio" role="form">


  <div class="form-group">
    <label for="inputEmail1" class="col-lg-2 control-label">Nome</label>
    <div class="col-md-6">
      <input type="text" name="TITULO_EXERPLAT" required class="form-control" id="TITULO_EXERPLAT" placeholder="Título">
    </div>
  </div>

  <div class="form-group">
    <div class="col-lg-offset-2 col-lg-10">
      <button type="submit" class="btn btn-primary">Inscrever</button>
    </div>
  </div>
</form>
</div>
</div>
	</div>
</div>