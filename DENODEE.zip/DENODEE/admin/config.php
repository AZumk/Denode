<?php 
	class DBRel{
		
		function DBConn(){
			$conn = new mysqli("localhost", "root", "", "0002050");
			if ($conn->connect_error)
				die("Connection failed: " . $conn->connect_error);
			
			return $conn;
		}

		function redirect(){
			$flag=0;
			$conn=$this->DBConn();
			$sql="Select ID_PERFUSU from perfil_usuario";
			$result = $conn->query($sql);

		
			if($flag==0)
				header("login.php");

			$conn->close();
		}

		function redirectlogin(){
			$flag=0;
			$conn=$this->DBConn();
			$sql="Select ID_PERFUSU from perfil_usuario";
			$result = $conn->query($sql);

			if($_SESSION["NOME_PERFUSU"] == "admin")
				$flag=1;

			if($result->num_rows >0)
				while($row = $result->fetch_assoc())
					if($_SESSION["NOME_PERFUSU"] == $row["ID_PERFUSU"]){
						$flag=2;
						break;
					}

			else if($flag==1)
				header("Location: perfiladmin.php");
			else if($flag==2)
				header("Location:usuarios.php");

			$conn->close();
		}
	} 
?>