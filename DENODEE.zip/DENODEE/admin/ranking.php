<?php
	
	include "config.php";
	$obDBRel = new DBRel;
	$obDBRel->redirect();
	error_reporting(0);
	
	function abc(){
		$obDBRel = new DBRel;

		
		$conn = $obDBRel->DBConn();

		if ($conn->connect_error)
			die("Connection failed: " . $conn->connect_error);
	
		$sql = "SELECT ID_PERFUSU FROM perfil_usuario";
		$result = $conn->query($sql);
		
		//Inserting values in dropdown
		echo "<select name='STD'>";
		echo "<option value='idusuario'>Id Usuário</option>";

		if ($result->num_rows > 0)
			while ($row = $result->fetch_assoc())
				echo "<option value='" . $row['ID_PERFUSU'] . "'>" . $row['ID_PERFUSU'] . "</option>";
		else
			echo "0 results";
		echo "</select>";
		

		$conn->close();
	}
?>
<!DOCTYPE html>
	<head>
		<title>Gerenciar usuário</title>
		
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>

			
			<form action="ranking.php" method=POST>
				
				<div class=output>
					<?php
						$obDBRelb = new DBRel;
						$conn=$obDBRelb->DBConn();

						$sql="SELECT * FROM perfil_usuario order by PONTOS_PERFUSU DESC";
							$result = $conn->query($sql);
                              $i= 1; 
                            
						if($result->num_rows > 0 || $i){
							echo "<table class=slist>";
							echo "<tr>";
							echo "<th>Colocação &nbsp; &nbsp;</td> ";
						    echo "<th>Usuário</td> ";
							echo "<th>Pontuação</td>";
							echo "</tr>";
							while($row = $result->fetch_assoc()){
								echo "<tr>";
								echo 	"<td>" . $i++ . "° &nbsp; &nbsp;&nbsp; &nbsp;</td>";
								echo 	"<td>" . $row["NOME_PERFUSU"] . "</td>";
								echo 	"<td>" . $row["PONTOS_PERFUSU"] .  " &nbsp; &nbsp;</td>";
								echo "</tr>";
							}	
						}
						else
							echo "<div align='center' style='font-size:20px'>No Records.</div>";

						

						echo "</table>";

						$conn->close();
					?>
				</div>
			</form>
		</article>
	</body>
</html>