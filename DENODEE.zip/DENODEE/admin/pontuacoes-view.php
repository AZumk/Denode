<div class="row">
	<div class="col-md-12">
<div class="btn-group pull-right">

</div>


<div class="card">
  <div class="card-header" data-background-color="blue">
      <h4 class="title">Pontuações e conquistas</h4>
  </div>
  <div class="card-content table-responsive">


			
			</div>
			</div>
	

	</div>
</div>